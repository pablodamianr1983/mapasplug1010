<?php
$string['pluginname'] = 'Mapas';  // Nuevo nombre del plugin
$string['modulename'] = 'Mapas';  // Nuevo nombre del módulo
$string['modulenameplural'] = 'Mapas';
$string['mapasname'] = 'Nombre de la actividad';
$string['mapasintro'] = 'Introducción de la actividad';
$string['mapasmapurl'] = 'URL del Mapa';  // Nueva cadena
$string['mapasmapurl_help'] = 'Introduce la URL del mapa que deseas mostrar en esta actividad.';  // Ayuda para la URL del mapa
