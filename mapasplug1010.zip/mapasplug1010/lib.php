<?php
function mapas_supports($feature) {
    switch($feature) {
        case FEATURE_MOD_INTRO: return true;
        default: return null;
    }
}

function mapas_add_instance($mapas) {
    global $DB;
    $mapas->timecreated = time();
    return $DB->insert_record('mapas', $mapas);
}

function mapas_update_instance($mapas) {
    global $DB;
    $mapas->timemodified = time();
    $mapas->id = $mapas->instance;
    return $DB->update_record('mapas', $mapas);
}

function mapas_delete_instance($id) {
    global $DB;
    return $DB->delete_records('mapas', array('id' => $id));
}
