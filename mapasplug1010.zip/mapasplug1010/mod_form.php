<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/course/moodleform_mod.php');

class mod_mapas_mod_form extends moodleform_mod {
    
    function definition() {
        $mform = $this->_form;

        // Campo para el nombre de la actividad.
        $mform->addElement('text', 'name', get_string('mapasname', 'mod_mapas'), array('size' => '64'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');

        // Campo para la introducción.
        $this->standard_intro_elements();

        // Campo para seleccionar la URL del mapa.
        $mform->addElement('select', 'mapurl', get_string('mapasmapurl', 'mod_mapas'), $this->get_map_options());
        $mform->setType('mapurl', PARAM_URL);
        $mform->addHelpButton('mapurl', 'mapasmapurl', 'mod_mapas');

        // Añade los elementos estándar.
        $this->standard_coursemodule_elements();

        // Añade los botones de acción (Guardar/Cancelar).
        $this->add_action_buttons();
    }

    // Función que devuelve las opciones de los mapas.
    private function get_map_options() {
        return array(
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PLANISFERIO%20AITOFF%20N%C2%BA3_2023.jpg' => 'Planisferio Aitoff Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PLANISFERIO%20AITOFF%20N%C2%BA5%202023.jpg' => 'Planisferio Aitoff Nº5 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PLANISFERIO%20MERCATOR%20N%C2%BA3%202023.jpg' => 'Planisferio Mercator Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PLANISFERIO%20MERCATOR%20N%C2%BA5%202023.jpg' => 'Planisferio Mercator Nº5 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CONTINENTE%20AMERICANO%20POL%20MUDO%20N%C2%BA3_2023.jpg' => 'Continente Americano Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ARG%20BICO%20FISICO%20A4%202021.jpg' => 'Argentina Bicontinental Físico A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ARG%20BICO%20INVERTIDO%20COPLA%20A4%202021.jpg' => 'Argentina Bicontinental Invertido COPLA A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ARG%20BICO%20N%C2%BA5%20mudo%202023.jpg' => 'Argentina Bicontinental Mudo Nº5 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ARG%20BICO%20POLITICO%20COPLA%20A4%202021.jpg' => 'Argentina Bicontinental Político COPLA A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ARG%20BICO%20SATELITAL%20A4%202021.jpg' => 'Argentina Bicontinental Satelital A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ARG%20PCA%20N%C2%BA3%20mudo%202023.jpg' => 'Argentina PCA Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/BUENOS%20AIRES%20FISICO%20WEB%202017.jpg' => 'Buenos Aires Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/BUENOS%20AIRES%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Buenos Aires Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/BUENOS%20AIRES%20POLITICO%20WEB%202017.jpg' => 'Buenos Aires Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/BUENOS%20AIRES%20SATELITAL%20WEB%202017.jpg' => 'Buenos Aires Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CATAMARCA%20FISICO%20WEB%202017.jpg' => 'Catamarca Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CATAMARCA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Catamarca Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CATAMARCA%20POLITICO%20WEB%202017.jpg' => 'Catamarca Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CATAMARCA%20SATELITAL%20WEB%202017.jpg' => 'Catamarca Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CABA%20FISICO%20WEB%202017.jpg' => 'CABA Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CABA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'CABA Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CABA%20POLITICO%20WEB%202017.jpg' => 'CABA Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CABA%20SATELITAL%20WEB%202017.jpg' => 'CABA Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHACO%20FISICO%20WEB%202017.jpg' => 'Chaco Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHACO%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Chaco Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHACO%20POLITICO%20WEB%202017.jpg' => 'Chaco Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHACO%20SATELITAL%20WEB%202017.jpg' => 'Chaco Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHUBUT%20FISICO%20WEB%202017.jpg' => 'Chubut Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHUBUT%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Chubut Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHUBUT%20POLITICO%20WEB%202017.jpg' => 'Chubut Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CHUBUT%20SATELITAL%20WEB%202017.jpg' => 'Chubut Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORDOBA%20FISICO%20WEB%202017.jpg' => 'Córdoba Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORDOBA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Córdoba Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORDOBA%20POLITICO%20WEB%202017.jpg' => 'Córdoba Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORDOBA%20SATELITAL%20WEB%202017.jpg' => 'Córdoba Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORRIENTES%20FISICO%20WEB%202017.jpg' => 'Corrientes Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORRIENTES%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Corrientes Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORRIENTES%20POLITICO%20WEB%202017.jpg' => 'Corrientes Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/CORRIENTES%20SATELITAL%20WEB%202017.jpg' => 'Corrientes Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ENTRE%20RIOS%20FISICO%20WEB%202017.jpg' => 'Entre Ríos Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ENTRE%20RIOS%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Entre Ríos Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ENTRE%20RIOS%20POLITICO%20WEB%202017.jpg' => 'Entre Ríos Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ENTRE%20RIOS%20SATELITAL%20WEB%202017.jpg' => 'Entre Ríos Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/FORMOSA%20FISICO%20WEB%202017.jpg' => 'Formosa Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/FORMOSA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Formosa Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/FORMOSA%20POLITICO%20WEB%202017.jpg' => 'Formosa Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/FORMOSA%20SATELITAL%20WEB%202017.jpg' => 'Formosa Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/JUJUY%20FISICO%20WEB%202017.jpg' => 'Jujuy Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/JUJUY%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Jujuy Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/JUJUY%20POLITICO%20WEB%202017.jpg' => 'Jujuy Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/JUJUY%20SATELITAL%20WEB%202017.jpg' => 'Jujuy Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LA%20PAMPA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'La Pampa Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/small/LAPAMPA%20SATELITAL%20WEB%202017.jpg' => 'La Pampa Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LAPAMPA%20POLITICO%20WEB%202017.jpg' => 'La Pampa Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LAPAMPA%20SATELITAL%20WEB%202017.jpg' => 'La Pampa Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LA%20RIOJA%20FISICO%20WEB%20%202017.jpg' => 'La Rioja Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LA%20RIOJA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'La Rioja Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LA%20RIOJA%20POLITICO%20WEB%202017.jpg' => 'La Rioja Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/LA%20RIOJA%20SATELITAL%20WEB%202017.jpg' => 'La Rioja Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MENDOZA%20FISICO%20WEB%202017.jpg' => 'Mendoza Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MENDOZA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Mendoza Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MENDOZA%20POLITICO%20WEB%202017.jpg' => 'Mendoza Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MENDOZA%20SATELITAL%20WEB%202017.jpg' => 'Mendoza Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MISIONES%20FISICO%20WEB%202017.jpg' => 'Misiones Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MISIONES%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Misiones Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MISIONES%20POLITICO%20WEB%202023.jpg' => 'Misiones Político 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MISIONES%20SATELITAL%20WEB%202017.jpg' => 'Misiones Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/NEUQUEN%20FISICO%20WEB%202017.jpg' => 'Neuquén Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/NEUQUEN%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Neuquén Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/small/NEUQUEN%20SATELITAL%20WEB%202017.jpg' => 'Neuquén Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/RIO%20NEGRO%20FISICO%20WEB%202017.jpg' => 'Río Negro Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/RIO%20NEGRO%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Río Negro Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/RIO%20NEGRO%20POLITICO%20WEB%202017.jpg' => 'Río Negro Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/RIO%20NEGRO%20SATELITAL%20WEB%202017.jpg' => 'Río Negro Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SALTA%20FISICO%20WEB%202017.jpg' => 'Salta Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SALTA%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Salta Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SALTA%20POLITICO%20WEB%202017.jpg' => 'Salta Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SALTA%20SATELITAL%20WEB%202017.jpg' => 'Salta Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20JUAN%20FISICO%20WEB%202017.jpg' => 'San Juan Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20JUAN%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'San Juan Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20JUAN%20POLITICO%20WEB%202017.jpg' => 'San Juan Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20JUAN%20SATELITAL%20WEB%202017.jpg' => 'San Juan Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20LUIS%20FISICO%20WEB%202017.jpg' => 'San Luis Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20LUIS%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'San Luis Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20LUIS%20POLITICO%20WEB%202017.jpg' => 'San Luis Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SAN%20LUIS%20SATELITAL%20WEB%202017.jpg' => 'San Luis Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20CRUZ%20FISICO%20WEB%202017.jpg' => 'Santa Cruz Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20CRUZ%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Santa Cruz Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20CRUZ%20POLITICO%20WEB%202017.jpg' => 'Santa Cruz Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20CRUZ%20SATELITAL%20WEB%202017.jpg' => 'Santa Cruz Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20FE%20FISICO%20WEB%202017.jpg' => 'Santa Fe Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20FE%20POLITICO%20WEB%202017.jpg' => 'Santa Fe Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTA%20FE%20SATELITAL%20WEB%202017.jpg' => 'Santa Fe Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTIAGO%20DEL%20ESTERO%20FISICO%20WEB%202017.jpg' => 'Santiago del Estero Físico 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTIAGO%20DEL%20ESTERO%20POL%20MUDO%20N%C2%BA3%202023.jpg' => 'Santiago del Estero Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTIAGO%20DEL%20ESTERO%20POLITICO%20WEB%202017.jpg' => 'Santiago del Estero Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/SANTIAGO%20DEL%20ESTERO%20SATELITAL%20WEB%202017.jpg' => 'Santiago del Estero Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ANTARTIDA%20N%C2%BA3%20mudo%202023.jpg' => 'Antártida Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ISLA%20GRANDE%20FISICO%20POLITICO%20WEB%202017.jpg' => 'Isla Grande Físico Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ISLA%20GRANDE%20POL%20MUDO%20N%C2%BA3_2023.jpg' => 'Isla Grande Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ISLA%20GRANDE%20SATELITAL%20WEB%202017.jpg' => 'Isla Grande Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PCIA%20TDF%20FISICO%20A4%202021.jpg' => 'Tierra del Fuego Físico A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PCIA%20TDF%20N%C2%BA3%20mudo%202023.jpg' => 'Tierra del Fuego Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PCIA%20TDF%20POLITICO%20A4%202021%20.jpg' => 'Tierra del Fuego Político A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/PCIA%20TDF%20SATELITAL%20A4%202021.jpg' => 'Tierra del Fuego Satelital A4 2021',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ISLAS%20MALVINAS%20POL%20MUDO%20N%C2%BA3_2023.jpg' => 'Islas Malvinas Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MALVINAS%20FISICO%20POLITICO%20WEB%202017.jpg' => 'Islas Malvinas Físico Político 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/MALVINAS%20SATELITAL%20WEB%202017.jpg' => 'Islas Malvinas Satelital 2017',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/ISLAS%20MALVINAS%20POL%20MUDO%20N%C2%BA3_2023.jpg' => 'Islas Malvinas Político Mudo Nº3 2023',
            'https://www.ign.gob.ar/gallery-app/mapas-escolares-202307/medium/Islas-Malvinas-Imagen.jpg' => 'Islas Malvinas Imagen',
        );
    }
}
