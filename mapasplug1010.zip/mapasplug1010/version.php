<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_mapas'; // Nombre del componente actualizado.
$plugin->version = 2024082200; // Fecha actual y número de versión.
$plugin->requires = 2021051700; // Requiere Moodle 3.11 o superior.
$plugin->maturity = MATURITY_STABLE;
$plugin->release = 'v1.0';
