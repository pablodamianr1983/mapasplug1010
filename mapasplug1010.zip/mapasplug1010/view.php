<?php
require_once('../../config.php');
require_once('lib.php');

$id = required_param('id', PARAM_INT);

// Obtén el módulo del curso y el contexto.
$cm = get_coursemodule_from_id('mapas', $id);  // Cambiado de 'simpleactivity' a 'mapas'
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
$mapas = $DB->get_record('mapas', array('id' => $cm->instance), '*', MUST_EXIST);

require_login($course, true, $cm); // Verifica que el usuario esté autenticado y en el contexto adecuado.

$context = context_module::instance($cm->id);
$PAGE->set_context($context); // Establece el contexto de la página.

$PAGE->set_url('/mod/mapas/view.php', array('id' => $id));  // Cambiado a la nueva URL
$PAGE->set_title($mapas->name);
$PAGE->set_heading($course->fullname);

echo $OUTPUT->header();

// Mostrar la introducción, asegurando que solo se muestre una vez.
if (!empty($mapas->intro)) {
    echo format_module_intro('mapas', $mapas, $cm->id);
}

// Mostrar el mapa si se ha proporcionado una URL.
if (!empty($mapas->mapurl)) {
    echo html_writer::tag('div', html_writer::empty_tag('img', array('src' => $mapas->mapurl, 'alt' => 'Mapa Escolar', 'style' => 'width:100%; height:auto;')), array('class' => 'mapas-map'));
}

echo $OUTPUT->footer();
